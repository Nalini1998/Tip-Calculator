# Tips Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/JjwGRGR/a2f3312cc95ed347f5d97dd59282431c](https://codepen.io/Nalini1998/pen/JjwGRGR/a2f3312cc95ed347f5d97dd59282431c).

